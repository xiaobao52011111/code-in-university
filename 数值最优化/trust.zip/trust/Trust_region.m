clc;
clear;
x = [10;10];%the initial guess
delta_bar = 2;
delta = delta_bar/3;
eta = 1/6;
err = 1e-5;
Ans = [];
[f,df,ddf] = func(x);
while norm(df) > err
   Ans = [Ans;x.',delta];
   d = solve_subproblem(df,ddf,delta);
   x1 = x+d;
   [f1,df1,ddf1] = func(x1);
   q1 = qunc(f1,df1,ddf1,d);
   r = (f-f1)/(f-q1);
   if r > 3/4
       delta = min(2*delta,delta_bar);
       x = x1;
   elseif r >= 1/4 && r <= 3/4 
       x = x1;
   elseif r > eta && r < 1/4
       delta = delta/2;
       x = x1;
   elseif r <= eta
       delta = delta/2;
   end
  [f,df,ddf] = func(x);
end


