function [f,df,ddf] = func(x)
% f = 10*(x(2)-x(1)).^2+(1-x(1)).^2;
% df = [20*(x(1)-x(2))+2*(x(1)-1);20*(x(2)-x(1))];
% ddf = [22,-20;-20,20];
syms x1; 
syms x2;
fx = 10*(x2-x1).^2+(1-x1).^2;
df1 = diff(fx,'x1');
df2 = diff(fx,'x2');
ddf_11 = diff(df1,'x1');
ddf_12 = diff(df1,'x2');
ddf_21 = diff(df2,'x1');
ddf_22 = diff(df2,'x2');
x1 = x(1);
x2 = x(2);
f_p = vectorize(fx);
df1_p = vectorize(df1);
df2_p = vectorize(df2);
ddf_11_p = vectorize(ddf_11);
ddf_12_p = vectorize(ddf_12);
ddf_21_p = vectorize(ddf_21);
ddf_22_p = vectorize(ddf_22);
f = eval(f_p);
df = [eval(df1_p);eval(df2_p)];
ddf = [eval(ddf_11_p),eval(ddf_12_p);eval(ddf_21_p),eval(ddf_22_p)];
end