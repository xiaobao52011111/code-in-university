function q = qunc(f,df,B,d)
q = f+df.'*d+1/2*d.'*B*d;
end