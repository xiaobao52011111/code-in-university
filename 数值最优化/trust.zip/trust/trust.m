clear all;clc 
x0 = [10;10];
delta1 = 2;
delta = 0.8;
eta = 1/6;
eps = 1e-5;
k = 0;
[f0,g0,h0] = fun(x0);
while k<1000 && norm(g0)>eps
    [f0,g0,h0] = fun(x0);
    d = solve(g0,h0,delta);
    x1 = x0+d;
    [f1,g1,h1] = fun(x1);
    deltaf = f0-f1;
    deltaq = f0-qun(f0,g0,h0,d);
    r = deltaf/deltaq;
    if r > 3/4
        delta = min(2*delta,delta1);
    elseif r >= 1/4
        delta = delta;
    elseif r > eta
        delta = delta/2;
    elseif r <= eta
        delta = delta/2;
        x0 =x1;
    end
k = k+1;
 

end
disp(k)
disp(x)
function [f,g,h] = fun(x)
f = 10*(x(2) - x(1))^2 + (1 - x(1) )^2;
g = [20*(x(1)-x(2))+2*(x(1)-1);20*(x(2)-x(1))];
h = [22 -20;
    -20 20];
end

function q = qun(f,g,B,d)
 q = f +g'*d + 1/2 *d' * B *d;
end

function  d_lambda = solve(df,B,delta)
lambda = 1;
d_lambda = -(B+lambda*eye(2))\df;
error = 1e-3;
while abs(1/delta -1/norm(d_lambda)) > error
    R = chol(B+lambda*eye(2));
    d_lambda = -(B+lambda*eye(2))\df;
    q_lambda = R.'\d_lambda;
    lambda = lambda+(norm(d_lambda)/norm(q_lambda)).^2*((norm(d_lambda)-delta)/delta);
    d_lambda = -(B+lambda*eye(2))\df;
end
end
% function dl = solve(g,h,delta)
% lamda = 1;
% err = 1e-3;
% dl = -(h + lamda*eye(2))\g;
% disp(h + lamda * eye(2));
% while abs(1/delta -1/norm(dl)) > err
%     R = chol(h + lamda*eye(2));
%     dl = -g\(h + lamda*eye(2));
%     ql = dl/R';
%     lamda = lamda+(norm(dl)/norm(ql))^2 *((norm(dl)-delta)/delta);
% end
% end