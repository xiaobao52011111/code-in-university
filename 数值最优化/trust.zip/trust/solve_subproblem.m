function  d_lambda = solve_subproblem(df,B,delta)
lambda = 1;
d_lambda = -(B+lambda*eye(2))\df;
error = 1e-3;
while abs(1/delta -1/norm(d_lambda)) > error
    R = chol(B+lambda*eye(2));
    d_lambda = -(B+lambda*eye(2))\df;
    q_lambda = R.'\d_lambda;
    lambda = lambda+(norm(d_lambda)/norm(q_lambda)).^2*((norm(d_lambda)-delta)/delta);
    d_lambda = -(B+lambda*eye(2))\df;
end
end
